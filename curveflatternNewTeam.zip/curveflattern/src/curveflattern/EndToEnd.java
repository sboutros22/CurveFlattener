package curveflattern;
public class EndToEnd {
   /* User opens program
Clicks on �file�
selects the upload image option
Image gets uploaded
user enters how much he wants the curve to be flattened by
 and selects whether he wants it to be by division or subtraction
The program produces a newly flattened image
Clicks on "file"
saves the new curve as either a png or jpg
 locates it in their files to make sure it saved properly
he now has a flattened curve of his students scores
 */
	
	
	 /* User opens program
	Clicks on �file�
	selects the upload spreadsheet option
	spreadsheet gets uploaded
	user enters how much he wants the curve to be flattened by
	 and selects whether he wants it to be by division or subtraction
	The program produces a newly flattened image
	Clicks on "file"
	saves the new curve as either a png or jpg
	 locates it in their files to make sure it saved properly
    he now has a flattened curve to make him look like there are less complaints every day than there actually is
	 */
}
