package curveflattern;

public class fancySliderNumber {

	/**
	 * Returns the value that the user selects on the slider to decrease their slope
	 * by.
	 * 
	 * @return
	 */
	public double getSliderNumber() {
		return 2;
	}
}
