package curveflattern;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class curve {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
